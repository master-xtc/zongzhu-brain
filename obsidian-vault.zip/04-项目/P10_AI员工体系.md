---
id: "P10"
cat: "项目"
tags: [总助大脑, 项目]
---

# AI员工体系

状态：一人公司运转中 ｜ 优先级：基础设施 ｜ 路径：D:\AI员工体系

总助Codex/Hermes/豆包/WorkBuddy/Claude/DSH 六编制；提示词库 28 条；growth 沉淀库 169 项资产

## 关联

- [[ROOT_总脑.md]]
