---
id: "E02"
cat: "员工"
tags: [总助大脑, 员工]
---

# Hermes

岗位：常驻值班执行岗 ｜ 状态：已上岗 v0.20.0

底座 NousResearch/hermes-agent；自带学习循环+子代理+cron+多平台+MCP；DeepSeek 接入；D:\AI工具\hermes；调用 hermes -z

## 关联

- [[ROOT_总脑.md]]
