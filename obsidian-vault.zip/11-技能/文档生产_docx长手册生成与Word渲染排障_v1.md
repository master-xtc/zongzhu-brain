# 技能｜Word 长文档（docx）脚本化生成、自动分页与 COM 渲染排障

- 技能名：文档生产_docx长手册生成与Word渲染排障
- 版本：v2（2026-09-21 增补自动分页、目录域、COM 样式覆盖三节）
- 适用模型：Codex（总助）/ Claude / WorkBuddy 均可执行
- 来源任务：20260921_市调大赛参赛手册

---

## 一、触发场景

1. 需要产出 **多章节、多表格、20 页以上**的正式 Word 交付物（参赛手册、项目方案、报价书、操作规范）。
2. 需要把 Word **导出成 PDF 或页图**做视觉验收。
3. 出现"Word 渲染卡死 / CPU 空转 / 无产出"，或"文档出现整页空白 / 尾页只剩一两行"的排障场景。

## 二、前置检查

- Python 解释器：本机为 `D:\XTC\python.exe`（不是系统 python，务必用绝对路径）。
- 依赖：`python-docx`（生成）、`PyMuPDF`（转页图与几何核验）。
- 数据落盘一律 D 盘，窗口产出存窗口主目录，团队公共库（growth / 提示词库）例外。

## 三、步骤

### A. 生成 docx

1. **先定结构再写代码**：把一级章节、二级标题、表格清单列成大纲，确认章节数再动手，避免中途大改脚本。
2. **脚本单文件化**：一份脚本从头生成整份文档，不做多文件拆段拼接（拆段拼接会让后续 patch 极易踩引号/缩进坑）。
3. **中文字体**：`run.font.name` 设置后必须再设 `run._element.rPr.rFonts.set(qn('w:eastAsia'), '黑体')`，否则中文回退默认字体。
4. **表格着色**：金色表头 `#C9A96A`、深色底 `#0A0A0F`；表头单元格统一 `shading` + 白字/深字加粗。
5. **页码域**：用 `PAGE` 域插入，不要写死数字。
6. **每次改脚本后立刻 `py_compile`**，再运行生成。

### B. 自动分页：解决"整页空白"与"尾页只剩一行"

7. **不要用 `doc.add_page_break()` 做章前分页**。它是一段独立的空分页符，当上一章内容刚好排到页底时，会凭空多出一整页空白。正确做法：给章标题段落设 `paragraph_format.page_break_before = True`（本手册用 `heading(..., new_page=True)` 参数封装）。
8. **不要给标题设 `keep_with_next`**。它会把"标题 + 紧随段落"整块推到下一页，既抵消行距压缩的收益，又容易造出空白页。标题孤行问题用 `page_break_before` 与版面密度解决更稳。
9. **删掉紧邻标题的空段**。`make_table()` / `callout()` 常会在末尾补一个 `para(doc, "", size=6)` 作为间隔；当上一张表刚好占满一页时，这个空段会被挤到下一页，再叠加标题的 `page_break_before`，就产生一页只剩空段的空白页。生成后统一扫一遍 body，删除"空段落 + 紧随 Heading"的组合。
10. **尾页只剩一两行时，定点收缩而不是全局重压**。全局改行距会让所有分页位置漂移，经常把 A 页的孤行变成 B 页的孤行（打地鼠）。有效手法：在出问题的那一章内部删减约 40 个汉字（一行），或把该章某张表的单元格文案压到少一行。目标只有一个：把溢出的一行收回上一页。
11. **版面密度的合理档位**（中文 10.5pt 正文、A4）：正文行距 1.18–1.25、段后 4–6pt、一级标题段前 11–13pt、表格内行距 1.1、单元格上下内边距 36–50 twips、表格单元格段前段后 0–1pt。低于这个区间会显拥挤，高于会明显拉长页数。

### C. 目录页（TOC 域）

12. **用真域，不要手写页码**：插入 `TOC \o "1-2" \h \z \u` 域，再让 Word 更新，页码才会跟着内容自动变。
13. **样式名是小写**：python-docx 默认模板里目录样式内部名为 `toc 1` / `toc 2`，不是 `TOC 1`。用大写名查会抛 `KeyError`，若外面套了 `except KeyError: continue` 会被静默吞掉，表现为"改了但没生效"。
14. **不要在 docx 里改目录样式就指望生效**：Word 更新目录域并保存时，会把目录样式上手工加的 `rPr` / `pPr` 剥掉。可靠做法是在 COM 里改：遍历 `$d.Styles`，匹配 `NameLocal` 以 `TOC` 开头，直接设 `Font.Size` / `ParagraphFormat`，再第二次更新目录域。
15. **更新目录域的调用顺序**：`TablesOfContents.Item(1).Update()` → 改样式 → 再 `Update()` → `Fields.Update()` → `Repaginate()` → `Save()` → `SaveAs2(pdf, 17)`。顺序颠倒会导致目录仍按旧样式排版。

### D. 表格宽度与提示框对齐

16. **表格总宽必须等于版心宽**：A4（21cm）减去左右边距（2.6 + 2.6）＝ 15.8cm。所有 `widths=[...]` 求和必须等于 15.8，否则表格要么缩进要么越界。改文案时最容易漏改这一项，建议在脚本里加一行断言或事后用正则把所有 `widths=[...]` 求和扫一遍。
17. **单格提示框（callout）要设 `t.alignment = WD_TABLE_ALIGNMENT.CENTER`**。左对齐的单格表，Word 会把边框画在版心左侧约一个单元格左边距（约 7pt）的位置，肉眼看到"左边凸、右边短"。居中对齐后边框正好落在版心内。多列表格同样建议统一设居中。

### E. 导出 PDF / 页图

18. **用 SaveAs2 而非 ExportAsFixedFormat**：`$d.SaveAs2($pdf, 17)` 更稳定。
19. **后台启动 + 看门狗**：`Start-Process powershell -WindowStyle Hidden` 起后台任务；主流程轮询完成标记文件，超时则 `Stop-Process -Name WINWORD -Force`。完成后同步写一个 `.done` 标记文件，供脚本判定。
20. **注意"标记文件残留"竞态**：主流程若在后台脚本删除旧标记之前就检查标记，会立刻误报成功（耗时 0.0s）。判定前先由主流程自己删掉标记，或校验 PDF 的 `LastWriteTime`。
21. **转页图**：PyMuPDF 按 105dpi 渲染每页 PNG，落 `_qa\页图_vN\page_XX.png`。

### F. 排障：Word 卡死

22. **症状**：CPU 空转、进程不退出、无文件产出、500 秒以上无响应。
23. **根因（本机实证）**：多个进程/子代理并发拉起 Word 实例抢占，前台渲染被饿死。
24. **处理顺序**：`Stop-Process -Name WINWORD -Force` 清场 → 确认无并发调用 → 改 SaveAs2 + 后台 + 看门狗 → 重跑。
25. **预防**：渲染阶段禁止并发；同一时刻只允许一个 Word COM 调用。

## 四、验收标准

- **几何核验脚本**（可替代一部分目视）：逐页算正文块的内容顶端/底端与填充率、所有图形（表格边框）的左右边界。判定阈值：图形左边界 73.7pt、右边界 523.3pt（A4 + 2.6cm 边距）；填充率低于 20% 视为异常页；正文块数为 0 视为空白页。
- **注意几何核验的坑**：`page.get_text("blocks")` 会把页眉/页脚也算成块，必须先按文本内容剔除，否则会把"空白页"误判成有内容，或把有内容的页判成空白。
- **视觉核对**：**必须派具备视觉能力的下属逐页看图**，回报"page_XX：OK / 问题描述"，总助不得自行断言版面结果。几何核验与视觉核对是两条独立轨，都要过。
- 结构核验通过：章节数、表格数、正文字符数符合预期；关键词命中率 ≥ 90%；无 `{占位符}` / `TODO` / `XXX`；无隐私泄露（真实姓名、手机号、身份证）。
- 页图页数 = PDF 页数 = 文档预期页数。

## 五、踩坑记录

| 现象 | 根因 | 解法 |
|---|---|---|
| 脚本 SyntaxError | patch 时引号混用（双引号开、单引号续） | 改完立即 `py_compile` |
| 中文显示为默认字体 | 只设了 `font.name` | 追加 `rFonts` 的 `w:eastAsia` |
| Word 渲染卡死 | 并发 Word COM 抢占 | Stop-Process + SaveAs2 + 后台看门狗 |
| 页码全为 1 | 直接写死数字 | 改用 `PAGE` 域 |
| 表格跨页断裂难看 | 未设 repeat header | `tblHeader` 属性 + `cantSplit` |
| 整页空白 | `add_page_break()` 恰好落在页边界之后 | 改用标题 `page_break_before` |
| 空白页（只剩空段） | 表格末尾的间隔空段被挤到下一页，再叠加标题分页 | 生成后删除"空段 + Heading"组合 |
| 提示框左边凸、右边短 | 单格表未设居中，边框左偏约一个单元格左边距 | `t.alignment = WD_TABLE_ALIGNMENT.CENTER` |
| 某张表比别的表格窄 | `widths` 求和 ≠ 15.8cm | 正则扫全部 widths 求和校验 |
| 改了目录样式不生效 | 样式名须小写 `toc 1`；且 Word 保存时会剥掉手改的样式 | COM 内改 `$d.Styles`，两次更新目录域 |
| 尾页只剩一行 | 章内容刚好溢出一行 | 在该章内定点删减约一行文字，不做全局重压 |
| 看门狗误报成功（0.0s） | 旧的 .done 标记残留 | 主流程先删标记，或校验 PDF 写入时间 |

---

## 六、补充：目录（TOC）页数与行高控制（2026-09-21 v4 实战补录）

### 问题现象

给 `toc 1` / `toc 2` 样式设了字号与行距，导出后目录仍按 ~25pt 行高排版，65 条目录条目撑成 3 页、末页只剩 5 条。压缩行距后末页反而只剩 2 条（更难看）。

### 定位方法（关键）

不要靠猜。用 COM 直接问 Word"这段实际用了什么格式"：

```powershell
foreach ($p in $d.Paragraphs) {
  $sn = [string]$p.Style.NameLocal
  if ($sn -like "TOC*") {
    "{0} font={1} lineRule={2} line={3} before={4} after={5}" -f `
      $sn, $p.Range.Font.Size, $p.Format.LineSpacingRule, $p.Format.LineSpacing,
      $p.Format.SpaceBefore, $p.Format.SpaceAfter
  }
}
```

实测结果：`TOC 1` 段落已吃到设置（lineRule=4 固定值、line=13pt、after=0），**`TOC 2` 段落没有**（lineRule=5 倍数、line=14.2、after=4，即仍然继承 Normal）。也就是说"样式设了但只有一个层级生效"，此前用页面几何反推是查不出来的。

### 可靠解法：样式层 + 段落层双保险

```powershell
# 1) 先更新一次目录域，生成条目
$d.TablesOfContents.Item(1).Update()

# 2) 样式层：用 -like "TOC*" 匹配，不要用 -eq "TOC 1" / -eq "TOC 2"
foreach ($st in $d.Styles) {
  $n = [string]$st.NameLocal
  if ($n -like "TOC*") {
    $st.Font.Size = 10
    $st.ParagraphFormat.SpaceBefore = 0
    $st.ParagraphFormat.SpaceAfter = 0
    $st.ParagraphFormat.LineSpacingRule = 4   # wdLineSpaceExactly
    $st.ParagraphFormat.LineSpacing = 15
  }
}

# 3) 段落层：本次渲染立即生效（更新目录域会重置直接格式，所以必须放在 Update 之后）
foreach ($p in $d.Paragraphs) {
  $sn = [string]$p.Style.NameLocal
  if ($sn -like "TOC*") {
    $p.Format.SpaceBefore = 0; $p.Format.SpaceAfter = 0
    $p.Format.LineSpacingRule = 4; $p.Format.LineSpacing = 15
    $p.Range.Font.Size = 10
  }
}

# 4) 之后不要再调用 TablesOfContents.Update()，否则直接格式会被冲掉
$d.Fields.Update(); $d.Repaginate(); $d.Save(); $d.SaveAs2($pdf, 17)
```

### 目录页数怎么定档（A4、版心 727pt 高）

- 条目数 N × 单条行高 ≈ 目录总高；超过 727pt 就多一页。
- **不要追求"刚好压进一页"**：压到 730–760pt 这种临界值，会多出一页只有 2–5 条的尾页，比 2 页更难看。
- 正确做法是**主动选档**：让总高落在 950–1100pt，目录稳定占 2 页、第二页约 40%–50% 填充，视觉上正常。本手册取 `TOC 1 = 16pt`、`TOC 2 = 15pt`，65 条 → 2 页、次页 46%。
- 如果条目太多（>90 条），考虑把附录子标题降为三级标题（不进目录），或把目录做成两栏无框表格。

### 页码正确性怎么验

目录域更新与导出在同一次 COM 会话内完成，页码必然一致；但**改版后必须抽查**：从目录文本里正则提取"标题 …… 页码"，再在 PDF 里按首行匹配同标题所在页，逐条比对。本手册抽查 6 条（章节、附录、附录子节）全部一致。
